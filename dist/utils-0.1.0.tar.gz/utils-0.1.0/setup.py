# setup.py
from distutils.core import setup

setup(
    name='utils',
    version='0.1.0',
    author='yuteng',
    py_modules=['utils.rl_utils'],
)